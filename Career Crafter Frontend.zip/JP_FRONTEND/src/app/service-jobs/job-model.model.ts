export interface JobDto {
  id?: number;
  title?: string;
  description?: string;
  designation?: string;
  company?: string;
  postedByName?: string;
  salary?: string;
  location?: string;
}
