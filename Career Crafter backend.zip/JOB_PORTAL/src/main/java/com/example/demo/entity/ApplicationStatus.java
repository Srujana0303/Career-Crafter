package com.example.demo.entity;

public enum ApplicationStatus {
	
	Applied,
	Reviewed,
	Accepted,
	Rejected
}
