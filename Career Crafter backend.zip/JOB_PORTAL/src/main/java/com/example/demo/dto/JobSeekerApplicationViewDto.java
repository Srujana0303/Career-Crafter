package com.example.demo.dto;

import lombok.Data;

@Data
public class JobSeekerApplicationViewDto {
    private ApplicationDto application;  
    private JobDto job;                 
}
