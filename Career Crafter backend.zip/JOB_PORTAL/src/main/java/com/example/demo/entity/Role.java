package com.example.demo.entity;

public enum Role {
	
	Employer,
	Job_Seeker

}
